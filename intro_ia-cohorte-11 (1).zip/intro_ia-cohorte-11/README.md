# Introducción a Inteligencia Artificial
Este repositorio contiene el material de clases (presentaciones, ejercicios y notebooks) para Introducción a la Inteligencia Artificial (CEIA - FIUBA)

### Organización del Repositorio

``` 
    Clase #
        presentaciones
        ejercicios
            data
            src
            tests
        juypterbooks
            data
            notebooks
        README.md
```

### Requerimientos
* Lenguaje de Programación
    * Python 3.8
    * Pip para instalar librerías
* Librerías
    * Numpy 1.18
    * SciPy 1.5
* Consola Interactiva de Python 
    * IPython
* Herramientas
    * PyTest para tests
    * GitHub para repositorios
* IDE Recomendado 
    * VS Code
