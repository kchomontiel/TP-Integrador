# Guía de Ejercicios Cohorte 6

1) Notebook de ejercicios unitarios para práctica de operaciones.
2) Presentación del TP1.